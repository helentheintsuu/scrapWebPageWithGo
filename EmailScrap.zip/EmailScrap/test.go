package main

import (
	"fmt"
	"github.com/PuerkitoBio/goquery"
	"time"
	"net/http"
	"strings"
)

func getListing(listingURL string) []string {
	var links []string
	//HTTP client with timeout
	var client = &http.Client{
		Timeout: 30 * time.Second,
	}
	request, err := http.NewRequest("GET", listingURL, nil)
	if err != nil {
		fmt.Println(err)
	}

	//Setting headers
	request.Header.Set("pragma", "no-cache")
	request.Header.Set("cache-control", "no-cache")
	request.Header.Set("dnt", "1")
	request.Header.Set("upgrade-insecure-requests", "1")
	request.Header.Set("referer", "https://isecom.org/")
	resp, err := client.Do(request)

	if resp.StatusCode == 200 {
		doc, err := goquery.NewDocumentFromReader(resp.Body)
		if err != nil {
			fmt.Println(err)
		}
		doc.Find("p").Each(func(i int, s *goquery.Selection) {
			//link, _ := s.Attr("href")
			//link = "https://isecom.org/" + link



			// Make sure you we only fetch correct URL with corresponding title

					//


					links = append(links, s.Text())




		})
	}

	return links
}


func main(){
	m := getListing("https://isecom.org")
	fmt.Println(strings.Join( m, "\n"))
}