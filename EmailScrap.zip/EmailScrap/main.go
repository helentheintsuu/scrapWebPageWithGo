package main
//
//import (
//	"fmt"
//	"net/http"
//	"github.com/PuerkitoBio/goquery"
//	"strings"
//	"time"
//)
//
////func getListing(listingURL string){
////	response, err := http.Get(listingURL)
////	if err != nil{
////	fmt.Println(err)
////	}
////	defer response.Body.Close()
////
////	if response.StatusCode ==200 {
////		body, err := ioutil.ReadAll(response.Body)
////		if err != nil{
////			fmt.Println(err)
////		}
////		fmt.Print("result")
////		fmt.Println(body)
////
////
////	}
////}
//
//func getListing(listingURL string) []string {
//	var links []string
//	//HTTP client with timeout
//	client := &http.Client{
//		Timeout: 30 * time.Second,
//	}
//	request, err := http.NewRequest("GET", listingURL, nil)
//	if err != nil {
//		fmt.Println(err)
//	}
//
//	//Setting headers
//	request.Header.Set("pragma", "no-cache")
//	request.Header.Set("cache-control", "no-cache")
//	request.Header.Set("dnt", "1")
//	request.Header.Set("upgrade-insecure-requests", "1")
//	request.Header.Set("referer", "https://isecom.org/")
//	resp, err := client.Do(request)
//
//	if resp.StatusCode == 200 {
//		doc, err := goquery.NewDocumentFromReader(resp.Body)
//		if err != nil {
//			fmt.Println(err)
//		}
//
//		doc.Find("p")
//		doc.Find("p").Each(func(i int, s *goquery.Selection) {
//			link, _ := s.Attr("p")
//			link = "https://isecom.org" + link
//
//			// Make sure you we only fetch correct URL with corresponding title
//			if strings.Contains(link, "p") {
//				text := s.Text()
//				if text != "" && text != "more" { //to avoid unecessary links
//					//
//					links = append(links, link)
//				}
//
//			}
//
//		})
//	}
//
//	return links
//}
//
//func main(){
//	m := getListing("https://isecom.org")
//	fmt.Println(m, "\n")
//
//}