package models

import (
	"fmt"
	"github.com/PuerkitoBio/goquery"
	"log"
	"net/http"
	"strings"
	"time"
)

type Response struct {
	data string `json:"data"`
}


func GetAllTExtDataFromURL(webUrlValue string) []string {

	var links []string
	//HTTP client with timeout
	 splitValue := strings.Split(webUrlValue, "@")
	var client = &http.Client{
		Timeout: 30 * time.Second,
	}
	if len(splitValue)> 1 {
		webUrl := "https://"+ splitValue[1]
		log.Print("split Value", splitValue)
		request, err := http.NewRequest("GET", webUrl, nil)
		if err != nil {
			fmt.Println(err)
		}
		log.Println("model weburl", webUrl)
		//Setting headers
		request.Header.Set("pragma", "no-cache")
		request.Header.Set("cache-control", "no-cache")
		request.Header.Set("dnt", "1")
		request.Header.Set("upgrade-insecure-requests", "1")
		link := webUrl+"/"
		log.Println("Url link", link)
		request.Header.Set("referer", link)
		resp, err := client.Do(request)

		if resp.StatusCode == 200 {
			doc, err := goquery.NewDocumentFromReader(resp.Body)
			if err != nil {
				fmt.Println(err)
			}
			doc.Find("p").Each(func(i int, s *goquery.Selection) {

				links = append(links, s.Text())

			})
		}
	}


	return links

}

func Find(key string) *Response {
	var getBook Response
	return &getBook
}
