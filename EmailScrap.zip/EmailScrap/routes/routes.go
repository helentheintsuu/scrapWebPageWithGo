package routes



import (
"EmailScrap/controllers"
	"github.com/gorilla/mux"
)

var  RegisterRoutes = func(router *mux.Router) {
	router.HandleFunc("/emailscrap/getTextData/{web_Url}", controllers.GetAllTextData).Methods("GET")
}
