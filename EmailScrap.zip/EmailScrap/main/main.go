package main

import (
	"EmailScrap/routes"
	"github.com/gorilla/mux"
	"log"
	"net/http"
)

func main() {
	r := mux.NewRouter()
	routes.RegisterRoutes(r)
	http.Handle("/", r)
	log.Println("Service Start")
	log.Fatal(http.ListenAndServe("localhost:8080", r))
}
