package controllers


import (
	"EmailScrap/models"
	_ "EmailScrap/utils"
	"encoding/json"
	"log"
	"net/http"
	"github.com/gorilla/mux"



)


func GetAllTextData(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	webUrlLink := vars["web_Url"]
	log.Println("controller web url", webUrlLink)
	textData := models.GetAllTExtDataFromURL(webUrlLink)
	res, err := json.Marshal(textData)
	if err != nil {
		log.Println("Errors")
		log.Println(err)
	}
	w.Header().Set("Content-Type", "pkglication/json")
	w.WriteHeader(http.StatusOK)
	w.Write(res)
}




